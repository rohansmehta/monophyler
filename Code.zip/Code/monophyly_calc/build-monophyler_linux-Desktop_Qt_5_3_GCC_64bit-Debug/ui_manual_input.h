/********************************************************************************
** Form generated from reading UI file 'manual_input.ui'
**
** Created by: Qt User Interface Compiler version 5.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANUAL_INPUT_H
#define UI_MANUAL_INPUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Manual_Input
{
public:
    QGridLayout *gridLayout;
    QComboBox *chooseCalcBox;
    QSpinBox *numSpeciesBox;
    QLabel *label;
    QLineEdit *treebox;
    QLabel *label_2;
    QLineEdit *Sbox;
    QLabel *label_3;
    QLineEdit *Tbox;
    QLabel *label_5;
    QFrame *line_4;
    QLineEdit *Cbox;
    QLabel *label_4;
    QComboBox *monocondbox;
    QLabel *label_6;
    QFrame *line_3;
    QTextEdit *treestatus;
    QTextEdit *generalstatus;
    QTextEdit *ssamplestatus;
    QTextEdit *branchlengthstatus;
    QTextEdit *csamplestatus;
    QPushButton *handRunButton;
    QPushButton *handCancelButton;

    void setupUi(QWidget *Manual_Input)
    {
        if (Manual_Input->objectName().isEmpty())
            Manual_Input->setObjectName(QStringLiteral("Manual_Input"));
        Manual_Input->setEnabled(true);
        Manual_Input->resize(372, 455);
        QIcon icon;
        icon.addFile(QStringLiteral("testicon.png"), QSize(), QIcon::Normal, QIcon::Off);
        Manual_Input->setWindowIcon(icon);
        gridLayout = new QGridLayout(Manual_Input);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        chooseCalcBox = new QComboBox(Manual_Input);
        chooseCalcBox->setObjectName(QStringLiteral("chooseCalcBox"));

        gridLayout->addWidget(chooseCalcBox, 0, 0, 1, 1);

        numSpeciesBox = new QSpinBox(Manual_Input);
        numSpeciesBox->setObjectName(QStringLiteral("numSpeciesBox"));
        numSpeciesBox->setMinimum(1);

        gridLayout->addWidget(numSpeciesBox, 0, 1, 1, 1);

        label = new QLabel(Manual_Input);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 3, 1, 1);

        treebox = new QLineEdit(Manual_Input);
        treebox->setObjectName(QStringLiteral("treebox"));

        gridLayout->addWidget(treebox, 1, 0, 1, 1);

        label_2 = new QLabel(Manual_Input);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 1, 1, 1, 1);

        Sbox = new QLineEdit(Manual_Input);
        Sbox->setObjectName(QStringLiteral("Sbox"));

        gridLayout->addWidget(Sbox, 2, 0, 1, 1);

        label_3 = new QLabel(Manual_Input);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 2, 1, 1, 3);

        Tbox = new QLineEdit(Manual_Input);
        Tbox->setObjectName(QStringLiteral("Tbox"));

        gridLayout->addWidget(Tbox, 3, 0, 1, 1);

        label_5 = new QLabel(Manual_Input);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 3, 1, 1, 3);

        line_4 = new QFrame(Manual_Input);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_4, 4, 0, 1, 4);

        Cbox = new QLineEdit(Manual_Input);
        Cbox->setObjectName(QStringLiteral("Cbox"));

        gridLayout->addWidget(Cbox, 5, 0, 1, 1);

        label_4 = new QLabel(Manual_Input);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 5, 1, 1, 3);

        monocondbox = new QComboBox(Manual_Input);
        monocondbox->setObjectName(QStringLiteral("monocondbox"));

        gridLayout->addWidget(monocondbox, 6, 0, 1, 1);

        label_6 = new QLabel(Manual_Input);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout->addWidget(label_6, 6, 1, 1, 2);

        line_3 = new QFrame(Manual_Input);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_3, 7, 0, 1, 1);

        treestatus = new QTextEdit(Manual_Input);
        treestatus->setObjectName(QStringLiteral("treestatus"));
        treestatus->setMaximumSize(QSize(16777215, 32));
        treestatus->setReadOnly(true);

        gridLayout->addWidget(treestatus, 8, 0, 1, 1);

        generalstatus = new QTextEdit(Manual_Input);
        generalstatus->setObjectName(QStringLiteral("generalstatus"));
        generalstatus->setEnabled(true);
        generalstatus->setReadOnly(true);

        gridLayout->addWidget(generalstatus, 8, 1, 3, 3);

        ssamplestatus = new QTextEdit(Manual_Input);
        ssamplestatus->setObjectName(QStringLiteral("ssamplestatus"));

        gridLayout->addWidget(ssamplestatus, 9, 0, 1, 1);

        branchlengthstatus = new QTextEdit(Manual_Input);
        branchlengthstatus->setObjectName(QStringLiteral("branchlengthstatus"));

        gridLayout->addWidget(branchlengthstatus, 10, 0, 1, 1);

        csamplestatus = new QTextEdit(Manual_Input);
        csamplestatus->setObjectName(QStringLiteral("csamplestatus"));

        gridLayout->addWidget(csamplestatus, 11, 0, 1, 1);

        handRunButton = new QPushButton(Manual_Input);
        handRunButton->setObjectName(QStringLiteral("handRunButton"));

        gridLayout->addWidget(handRunButton, 11, 1, 1, 1);

        handCancelButton = new QPushButton(Manual_Input);
        handCancelButton->setObjectName(QStringLiteral("handCancelButton"));

        gridLayout->addWidget(handCancelButton, 11, 2, 1, 2);

        QWidget::setTabOrder(chooseCalcBox, numSpeciesBox);
        QWidget::setTabOrder(numSpeciesBox, treebox);
        QWidget::setTabOrder(treebox, Sbox);
        QWidget::setTabOrder(Sbox, Tbox);
        QWidget::setTabOrder(Tbox, Cbox);
        QWidget::setTabOrder(Cbox, monocondbox);

        retranslateUi(Manual_Input);

        QMetaObject::connectSlotsByName(Manual_Input);
    } // setupUi

    void retranslateUi(QWidget *Manual_Input)
    {
        Manual_Input->setWindowTitle(QApplication::translate("Manual_Input", "Manual Input", 0));
        chooseCalcBox->clear();
        chooseCalcBox->insertItems(0, QStringList()
         << QApplication::translate("Manual_Input", "Choose calculation:", 0)
         << QApplication::translate("Manual_Input", "Single-subset", 0)
         << QApplication::translate("Manual_Input", "2 sp. reciprocal", 0)
         << QApplication::translate("Manual_Input", "3 sp. reciprocal", 0)
         << QApplication::translate("Manual_Input", "4 sp. reciprocal symmetric", 0)
         << QApplication::translate("Manual_Input", "4 sp. reciprocal asymmetric", 0)
        );
        label->setText(QApplication::translate("Manual_Input", "No. of species", 0));
        label_2->setText(QApplication::translate("Manual_Input", "Tree (no quotes)", 0));
        label_3->setText(QApplication::translate("Manual_Input", "S Sample Sizes (e.g. 2/3)", 0));
        label_5->setText(QApplication::translate("Manual_Input", "Branch lengths (e.g. 0.1/5001/1)", 0));
        label_4->setText(QApplication::translate("Manual_Input", "C Sample Sizes (e.g. 3/1/5)", 0));
        monocondbox->clear();
        monocondbox->insertItems(0, QStringList()
         << QApplication::translate("Manual_Input", "Monophyly condition:", 0)
         << QApplication::translate("Manual_Input", "S", 0)
         << QApplication::translate("Manual_Input", "C", 0)
         << QApplication::translate("Manual_Input", "SC", 0)
        );
        label_6->setText(QApplication::translate("Manual_Input", "Only for single-subset", 0));
        handRunButton->setText(QApplication::translate("Manual_Input", "Send to Input", 0));
        handCancelButton->setText(QApplication::translate("Manual_Input", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class Manual_Input: public Ui_Manual_Input {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANUAL_INPUT_H
