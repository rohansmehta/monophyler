/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLineEdit *inputFileNameBox;
    QPushButton *runButton;
    QProgressBar *progressBar;
    QLineEdit *outputFileNameBox;
    QLabel *label;
    QPlainTextEdit *outputTextBox;
    QComboBox *calcChoiceBox;
    QLabel *label_2;
    QPushButton *manualInputButton;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(357, 325);
        QIcon icon;
        icon.addFile(QStringLiteral("testicon.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        inputFileNameBox = new QLineEdit(centralWidget);
        inputFileNameBox->setObjectName(QStringLiteral("inputFileNameBox"));

        gridLayout->addWidget(inputFileNameBox, 0, 1, 1, 1);

        runButton = new QPushButton(centralWidget);
        runButton->setObjectName(QStringLiteral("runButton"));

        gridLayout->addWidget(runButton, 4, 2, 1, 1);

        progressBar = new QProgressBar(centralWidget);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setValue(0);

        gridLayout->addWidget(progressBar, 4, 0, 1, 2);

        outputFileNameBox = new QLineEdit(centralWidget);
        outputFileNameBox->setObjectName(QStringLiteral("outputFileNameBox"));

        gridLayout->addWidget(outputFileNameBox, 2, 1, 1, 1);

        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        outputTextBox = new QPlainTextEdit(centralWidget);
        outputTextBox->setObjectName(QStringLiteral("outputTextBox"));
        outputTextBox->setReadOnly(true);

        gridLayout->addWidget(outputTextBox, 3, 0, 1, 3);

        calcChoiceBox = new QComboBox(centralWidget);
        calcChoiceBox->setObjectName(QStringLiteral("calcChoiceBox"));

        gridLayout->addWidget(calcChoiceBox, 2, 2, 1, 1);

        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        manualInputButton = new QPushButton(centralWidget);
        manualInputButton->setObjectName(QStringLiteral("manualInputButton"));

        gridLayout->addWidget(manualInputButton, 0, 2, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(inputFileNameBox, outputFileNameBox);
        QWidget::setTabOrder(outputFileNameBox, calcChoiceBox);
        QWidget::setTabOrder(calcChoiceBox, runButton);
        QWidget::setTabOrder(runButton, manualInputButton);
        QWidget::setTabOrder(manualInputButton, outputTextBox);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Monophyler", 0));
        runButton->setText(QApplication::translate("MainWindow", "Run", 0));
        label->setText(QApplication::translate("MainWindow", "Input File", 0));
        calcChoiceBox->clear();
        calcChoiceBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Choose calculation:", 0)
         << QApplication::translate("MainWindow", "Single-subset", 0)
         << QApplication::translate("MainWindow", "2 sp. Reciprocal", 0)
         << QApplication::translate("MainWindow", "3 sp. Reciprocal", 0)
         << QApplication::translate("MainWindow", "4 sp. Reciprocal", 0)
        );
        label_2->setText(QApplication::translate("MainWindow", "Output File", 0));
        manualInputButton->setText(QApplication::translate("MainWindow", "Manual Input", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
